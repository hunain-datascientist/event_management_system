using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EventManagementSystem.Pages
{
    public class EventListModel : PageModel
    {
        public List<Event> Events { get; set; }

        public void OnGet()
        {
            // Sample list of events
            Events = new List<Event>
        {
            new Event { Name = "Event 1", Description = "Description for Event 1", Location = "Location 1", EventDate = DateTime.Now.AddDays(5) },
            new Event { Name = "Event 2", Description = "Description for Event 2", Location = "Location 2", EventDate = DateTime.Now.AddDays(10) },
        };
        }
    }

    public class Event
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Location { get; set; }
        public DateTime EventDate { get; set; }
    }

}
