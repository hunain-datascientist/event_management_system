using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EventManagementSystem.Pages
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public string Username { get; set; }

        [BindProperty]
        public string Password { get; set; }

        public string ErrorMessage { get; set; }

        public void OnGet()
        {
            // This method runs when the page loads (GET request)
        }

        public IActionResult OnPost()
        {
            if (Username == "admin" && Password == "password") // Hard-coded example
            {
                return RedirectToPage("/Dashboard");  // Redirect to Dashboard after successful login
            }
            else
            {
                ErrorMessage = "Invalid username or password.";
                return Page(); // Reload the page with an error
            }
        }
    }

}
