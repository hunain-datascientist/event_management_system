using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EventManagementSystem.Pages
{
    public class DashboardModel : PageModel
    {
        public string? WelcomeMessage { get; set; } = "Welcome to the dashboard!";

        public void OnGet()
        {
        }
    }
}
