using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EventManagementSystem.Pages
{
    public class CreateEventModel : PageModel
    {
        public string EventName { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string SuccessMessage { get; set; } = string.Empty;

        public void OnGet()
        {
        }

        public void OnPost()
        {
            // Add event creation logic here
            SuccessMessage = "Event created successfully!";
        }
    }
}
