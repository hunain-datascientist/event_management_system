using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EventManagementSystem.wwwroot.css
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
